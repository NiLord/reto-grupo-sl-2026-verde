package com.appbg.appbg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppbgApplicationTests {

	@Test
	void contextLoads() {
	}

}
